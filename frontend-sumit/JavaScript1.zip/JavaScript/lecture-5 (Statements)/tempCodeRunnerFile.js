
        for (let j=1;j<=i;j++){