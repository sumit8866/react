//  Javascript Statements  
/*
   if Statement
   if....else Statement
   Nested Statements
   if....else..if Statement (ladder)
   Switch case Statements
*/

// if statement

// {
//     let age= parseInt(
//         prompt(`Enter age`)
//     )
//     if (age>=18){
//         console.log('====================================');
//         console.log(`you are eligble for voting`);
//         console.log('====================================')
//     }
// }

// if....else Statement

// {
//     let age= parseInt(
//         prompt(`Enter age`)
//     )
//     if (age>=18){
//         console.log('====================================');
//         console.log(` your age is ${age} and you are eligble for voting`);
//         console.log('====================================')
//     }else{
//         console.log('====================================');
//         console.log(` your age is ${age} and you are not eligble for voting`);
//         console.log('====================================');
//     }
// }

// Nested Statements
{

    // let genders = prompt(`Enter gender`)

    // let age = parseInt(
    //     prompt(`Enter age`)
    // )
    // if (genders === "male") {
    //     if (age >= 18) {
    //         console.log('====================================');
    //         console.log(`you are hire`);
    //         console.log('====================================');
    //     } else {
    //         console.log('====================================');
    //         console.log(`you are not hire (you are just ${age} year old)`);
    //         console.log('====================================');
    //     }
    // } else {
    //     console.log('====================================');
    //     console.log(`you are not hire (you are just ${age} year old)`);
    //     console.log('====================================');
    // }

}

// if....else..if Statement (ladder)

{
    // const num1 = parseFloat(prompt("Enter first number: "));
    // const num2 = parseFloat(prompt("Enter second number: "));
    // const num3 = parseFloat(prompt("Enter third number: "));


    // if (num1 >= num2 && num1 >= num3) {
    //     console.log(`largest is ${num1}`);

    // }
    // else if (num2 >= num1 && num2 >= num3) {
    //     console.log(`largest is ${num2}`);
    // }
    // else {
    //     console.log(`largest is ${num3}`);
    // }
}

{

    // let mark = parseInt(
    //     prompt(`Enter mark`)
    // )
    // if(mark >= 90){
    //     console.log('====================================');
    //     console.log(`Grade - A`);
    //     console.log('====================================');
    // }else if(mark >= 70 && mark <=89){
    //     console.log('====================================');
    //     console.log(`Grade - B`);
    //     console.log('====================================');
    // }else if(mark >= 50 && mark <=69){
    //     console.log('====================================');
    //     console.log(`Grade - C`);
    //     console.log('====================================');
    // }else if(mark >= 33 && mark <=49){
    //     console.log('====================================');
    //     console.log(`Grade - D`);
    //     console.log('====================================');
    // }else{
    //     console.log('====================================');
    //     console.log(`FAIL`);
    //     console.log('====================================');
    // }
}


//Switch case Statements


{
    // let car =  prompt(`Enter car name`)

    // switch(car){
    //     case "bmw":console.log('====================================');
    //     console.log(`BMW car is on sale`);
    //     console.log('====================================');
    //     break;
    //     case "hyundai":console.log('====================================');
    //     console.log(`Hyundai car is on sale`);
    //     console.log('====================================');
    //     break;
    //     case "mahindra":console.log('====================================');
    //     console.log(`Mahindra car is on sale`);
    //     console.log('====================================');
    //     break;
    //     case "nissan":console.log('====================================');
    //     console.log(`Nissan car is on sale`);
    //     console.log('====================================');
    //     break;
    //     case "ford":console.log('====================================');
    //     console.log(`Ford car is on sale`);
    //     console.log('====================================');
    //     break;
    //     default :console.log('====================================');
    //     console.log(`${car} car is not on sale`);
    //     console.log('====================================');
    // }
}

{
    // xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
    //     let mark = parseInt(
    //         prompt(`Enter mark name`)
    //     )

    // switch(mark){
    //     case (mark >= 90):console.log('====================================');
    //     console.log(`Grade - A`);
    //     console.log('====================================');
    //     break;
    //     case (mark >= 70 && mark <=89):console.log('====================================');
    //     console.log(`Grade - B`);
    //     console.log('====================================');
    //     break;
    //     case (mark >= 50 && mark <=69):console.log('====================================');
    //     console.log(`Grade - C`);
    //     console.log('====================================');
    //     break;
    //     case (mark >= 33 && mark <=49):console.log('====================================');
    //     console.log(`Grade - D`);
    //     console.log('====================================');
    //     break;
    //     default :console.log('====================================');
    //     console.log(`FAIL`);
    //     console.log('====================================');
    // }
}


// Check if a number is positive, negative, or zero


{
    // let number= parseInt(prompt(`Enter number `))

    // if(number > 0){
    //     console.log(`number is positive`);
    // }else if(number < 0){
    //     console.log(`number is negative`);
    // }else {
    //     console.log(`number is zero`);

    // }
}


//Check if a person is eligible to vote


{
    // let age = parseInt(
    //     prompt(`Enter age`)
    // )
    // if (age >= 18) {
    //     console.log('====================================');
    //     console.log(` your age is ${age} and you are eligble for voting`);
    //     console.log('====================================')
    // } else {
    //     console.log('====================================');
    //     console.log(` your age is ${age} and you are not eligble for voting`);
    //     console.log('====================================');
    // }
}


// Determine the largest of three numbers


{
    // const num1 = parseFloat(prompt("Enter first number: "));
    // const num2 = parseFloat(prompt("Enter second number: "));
    // const num3 = parseFloat(prompt("Enter third number: "));


    // if (num1 >= num2 && num1 >= num3) {
    //     console.log(`largest is ${num1}`);

    // }
    // else if (num2 >= num1 && num2 >= num3) {
    //     console.log(`largest is ${num2}`);
    // }
    // else {
    //     console.log(`largest is ${num3}`);
    // }


}
{
    // const num1 = parseFloat(prompt("Enter first number: "));
    // const num2 = parseFloat(prompt("Enter second number: "));
    // const num3 = parseFloat(prompt("Enter third number: "));
    // const num4 = parseFloat(prompt("Enter third number: "));

    // if (num1 >= num2 && num1 >= num3 && num1 >= num4) {
    //     console.log(`largest is ${num1}`);

    // }
    // else if (num2 >= num1 && num2 >= num3 && num2 >= num4) {
    //     console.log(`largest is ${num2}`);
    // }
    // else if(num3 >= num1 && num3 >= num2 && num3 >= num4){
    //     console.log(`largest is ${num3}`);
    // }else {
    //     console.log(`largest is ${num4}`);
    // }
}


//Check if a year is a leap year


{
    //  let year = parseInt(prompt(`Enter year`))

    //  if(year % 4 == 0){
    //     console.log(`this is leap year`);
    //  }else {
    //     console.log(`this is not leap year`);
    //  }
}


//Determine the grade based on a score


{
    // let mark = parseInt(
    //     prompt(`Enter mark`)
    // )
    // if(mark >= 90){
    //     console.log('====================================');
    //     console.log(`Grade - A`);
    //     console.log('====================================');
    // }else if(mark >= 70 && mark <=89){
    //     console.log('====================================');
    //     console.log(`Grade - B`);
    //     console.log('====================================');
    // }else if(mark >= 50 && mark <=69){
    //     console.log('====================================');
    //     console.log(`Grade - C`);
    //     console.log('====================================');
    // }else if(mark >= 33 && mark <=49){
    //     console.log('====================================');
    //     console.log(`Grade - D`);
    //     console.log('====================================');
    // }else{
    //     console.log('====================================');
    //     console.log(`FAIL`);
    //     console.log('====================================');
    // }
}

{
    // let p = ""
    // let n = parseInt(prompt(`Enter number`))

    // for (let i = 1; i <= n; i++) {
    //     for (let j = 1; j <= i; j++) {
    //         p += j;

    //     }
    //     p += "\n"
    // }
    // console.log(p);

}