//1. JavaScript Program To Print Hello World

{
    // let str = `Hello World`
    // console.log(str);

}


//2.JavaScript Program to Add Two Numbers

{
    // let n1 = 10
    // let n2 = 20
    // sum = n1 + n2
    // console.log(sum);

}


//3.JavaScript Program to Find the Square Root

{
    // let n = 25
    // g = n
    // let object = 0
    // while ((g - n / g) > object) {
    //     g = (g + n / g) / 2
    // }
    // console.log(g);

}

{
    // let a = 10

    // sum =a*a
    // console.log(`square of a is : ${sum}`);

}

// 4.JavaScript Program to Calculate the Area of a Triangle
// santex:
// 1/2 *b*h

{
    // let b = 10
    // let h = 10

    // let tri = 1/2 * b * h

    // console.log(`area of triangle : ${tri}`);

}

//5.JavaScript Program to Swap Two Variables

{
    // let x = 10
    // let y = 20

    // x = x + y
    // y = x - y
    // x = x - y

    // console.log(`now x value is: ${x}`);
    // console.log(`now y value is: ${y}`);

}

// 6.JavaScript Program to Solve Quadratic Equation

{







}


//7.JavaScript Program to Convert Kilometres to Miles

{
    // let km=10
    // let miles=0.621371

    // let mile= km * miles
    // console.log(`${km} Kilometres = ${mile} Miles`);

}

//8.Javascript Program to Convert Celsius to Fahrenheit

{
    // let c = 10
    // let f = (c * (9 / 5)) + 32

    // console.log(`${c} Celsius = ${f} Fahrenheit`);

}

//9.Javascript Program to Generate a Random Number

// using Math.random() function
{

    // console.log(Math.random()*100);

}

//10.Javascript Program to Check if a number is Positive, Negative, or Zero

{
    // let num = 0

    // if (num > 0) {
    //     console.log(`Number is Positive`);
    // } else if (num < 0) {
    //     console.log(`Number is Negative`);
    // } else {
    //     console.log(`Number is Zero`);
    // }
}

//11.Javascript Program to Check if a Number is Odd or Even

{
    // let num=3

    // if(num %= 2){
    //     console.log(`Number is Odd`)
    // }else{
    //     console.log(`Number is Even`);

    // }
}

//12.JavaScript Program to Find the Largest Among Three Numbers

{
    // let n1 = 10
    // let n2 = 30
    // let n3 = 200

    // if (n1 > n2 && n1 > n3) {
    //     console.log(`${n1}(n1) is Largest Numbers`);
    // } else if (n2 > n1 && n2 > n3) {
    //     console.log(`${n2}(n2) is Largest Numbers`);
    // } else {
    //     console.log(`${n3}(n3) is Largest Numbers`);
    // }
}

//13.JavaScript Program to Check Prime Number

{





}

//14.JavaScript Program to Print All Prime Numbers in an Interval

{





}

//15.JavaScript Program to Find the Factorial of a Number

{
    // let num =10

    // let fac=1

    // for(let i = 0;i<num ; i++){
    //     fac = fac * (num-i)
    // }
    // console.log(`factorial of ${num} is = ${fac}`);

}

//16.JavaScript Program to Display the Multiplication Table

{
    // let num = 69

    // for (let i = 1; i <= 10; i++) {
    //     let Table = num * i
    //     console.log(`${num} * ${i} = ${Table}`);
    // }
}

//17.JavaScript Program to Print the Fibonacci Sequence

{
    // let n = 20
    // let f1=0
    // let f2=1
    // console.log(`first ${n} numbers fibbonacci is: ${f1}`);
    // console.log(`first ${n} numbers fibbonacci is: ${f2}`);
    // for(let i=1 ;i<=n ; i++ ){

    //     fibbo = f1 + f2
    //     f1 = f2
    //     f2 = fibbo
    //     console.log(`first ${n} numbers fibbonaci is : ${fibbo}`);

    // }
}

//18.JavaScript Program to Check Armstrong Number

{





}

//19.JavaScript Program to Find Armstrong Number in an Interval

{





}

//20.JavaScript Program to Make a Simple Calculator

{
    // let num1 = parseInt(prompt(`Enter number 1`))
    // let num2 = parseInt(prompt(`Enter number 2`))
    // let calc = prompt(`Enter symbol for plus (+) ,
    //                   for minus (-) , 
    //                   for multiplication (*) , 
    //                   for division (/) `)
    // switch (calc) {
    //     case '+':
    //         let sum = num1 + num2
    //         console.log(`${num1} + ${num2} = ${sum}`);
    //         break;
    //     case '-':
    //         let sub = num1 - num2
    //         console.log(`${num1} - ${num2} = ${sub}`);
    //         break;
    //     case '*':
    //         let multi = num1 * num2
    //         console.log(`${num1} * ${num2} = ${multi}`);
    //         break;
    //     case '/':
    //         let div = num1 / num2
    //         console.log(`${num1} / ${num2} = ${div}`);
    //         break;
    //     default:
    //         console.log(`error`);
    //         break;
    // }
}

//21.JavaScript Program to Find the Sum of Natural Numbers


{
    // let num =100
    // let sum=0
    //     for(i=1 ; i<=num ; i++){
    //         sum+=i
    //     }
    //     console.log(sum);
}

// 22.JavaScript Program to Check if the Numbers Have Same Last Digit

{
    // let num1 = "100545"
    // let num2 = "250546"

    // let n1 = num1.split("")
    // let n2 = num2.split("")

    // console.log(n1)
    // console.log(n2)

    // // let l1= n1.length
    // // let l2= n2.length

    // // console.log(l1)
    // // console.log(l2)

    // if (n1[n1.length - 1] == n2[n2.length - 1]) {
    //     console.log(`${num1} and ${num2} both have same last digits.`);
    // }
    // else {
    //     console.log(`${num1} and ${num2} both have not same last digits.`);
    // }
}

// 23.JavaScript Program to Find HCF or GCD

{

    // let a = 18;
    // let b = 24;


    // let temp;
    // let originalB = b;

    // for (let temp = b; b !== 0;) {
    //     b = a % b;
    //     a = temp;
    //     temp = b;
    // }

    // console.log("GCD:", a);

}

//24.JavaScript Program to Find LCM

{

    // let a = 12;
    // let b = 18;

    // let temp;
    // let originalB = b;


    // while (b !== 0) {
    //     temp = b;
    //     b = a % b;
    //     a = temp;
    // }

    // console.log("GCD:", a);

    // let gcd = a;
    // let gcdValue = gcd;
    // let lcm = (a * originalB * 2) / gcdValue;

    // console.log("LCM:", lcm);


}

//25.JavaScript Program to Find the Factors of a Number

{

    // let num =48
    // for(let i = 1; i <= num; i++) {
    // if(num % i == 0) {
    //     console.log(i);
    // }
    // }
}

// 26.JavaScript Program to Find Sum of Natural Numbers Using Recursion

{





}

//27.JavaScript Program to Guess a Random Number

{

    // const random = Math.floor(Math.random() *10) + 1;

    // let number = parseInt(prompt('Guess a number from 1 to 10: '));

    // if(number == random) {
    //     console.log('You guessed the correct number.');
    // }
    // console.log(random);

}

// 28.JavaScript Program to Shuffle Deck of Cards

{
    //     let cards = ["Hearts", "Diamonds", "Clubs", "Spades"];
    // let values = [
    //     "A","King","Queen","Jack",
    //     "2", "3", "4", "5", "6",
    //     "7", "8", "9", "10",
    // ];

    // let res = [];

    // for (let card in cards) {
    //     for (let value in values) {
    //         res.push(values[value] + " of " + cards[card]);
    //     }
    // }

    // console.log(res);

}

// 29.JavaScript Program to Display Fibonacci Sequence Using Recursion

{





}
//30.JavaScript Program to Find Factorial of Number Using Recursion
{





}

//31.JavaScript Program to Convert Decimal to Binary

{
    //    let num =10
    //    let binary = ''

    //    while (num > 0) {
    //        binary = (num % 2) + binary;
    //        num = Math.floor(num / 2);
    //    }
    //    console.log(binary);

}

//32.JavaScript Program to Find ASCII Value of Character

{
    // let str=`a`

    // console.log(str.charCodeAt());

}
//33.JavaScript Program to Check Whether a String is Palindrome or Not

{






}

//34.JavaScript Program to Sort Words in Alphabetical Order

{

    // let str = "This is javascript program for sort word"

    // let array= str.split(" ")
    // console.log(array);

    // console.log(array.sort());


}

//35.JavaScript Program to Replace Characters of a String

{
    // let str = "This is javascript program for sort word"
    // let str1 = "sssssssssssssssssssssssssssss"

    // console.log(str.replace("sort word","replace word"));
    // console.log(str1.replaceAll("s","t"));

}

//36.JavaScript Program to Reverse a String


{
    // let str=`my name is sumit`

    // let array=str.split("")
    // console.log(array);

    // let Reverse = array.reverse()
    // console.log(Reverse);

    // let str1= Reverse.join("")

    // console.log(str1);

}

//37.JavaScript Program to Create Objects in Different Ways

{

    // let object1 = {
    //     name: "sumit",
    //     age: 20
    // }
    // console.log(object1);

    // let object2 = {}

    // object2.name = "hari"
    // object2.age = 25
    // console.log(object2);

    // const object3 = new Object();

    // object3.name = "jemish"
    // object3.age = 30
    // console.log(object3);

}

//38.JavaScript Program to Check the Number of Occurrences of a Character in the String

{
    // let str = `this that those whare whan why what`
    // let array1= str.split("")
    // let array2= str.split(" ")
    // let Occurrences ="whan"

    // count=0
    // for (let key of array1){
    //     if(key == Occurrences){
    //         count = count + 1
    //     }
    // }
    // for (let key of array2){
    //     if(key == Occurrences){
    //         count = count + 1
    //     }
    // }
    // console.log(array1);
    // console.log(array2);
    // console.log(count);

}

//39.JavaScript Program to Convert the First Letter of a String into UpperCase


{
    // let str = `good morning`

    // let UpperCase = str.charAt(0).toUpperCase() + str.slice(1);

    // console.log(UpperCase);
}

//40.JavaScript Program to Count the Number of Vowels in a String

{

    // let str = `good morning`
    // let array1= str.split("")
    // let array2= [`a`,`e`,`i`,`o`,`u`]
    // count=0
    // for (let key of array1){
    //     for(let keys of array2)
    //     if(key == keys){
    //         count = count + 1
    //     }
    // }
    // console.log(count);

}

//41.JavaScript Program to Remove a Property from an Object

{





}

//42.JavaScript Program to Check Whether a String Starts and Ends With Certain Characters

{

    // let object = {
    //     firstName: "raj",
    //     lastName: "shah",
    //     age: 40,
    // };

    // console.log(object);
    // delete object.age
    // console.log(object);

}

//43.JavaScript Program to Check if a Key Exists in an Object

{
    // let object = {
    //     firstName: "raj",
    //     lastName: "shah",
    //     age: 40,
    // };

    // let str=`age`

    // for (let key in object){

    //     if(key == str){
    //         console.log(`key is exists `);
    //     }else{
    //         console.log(`key is not exists`); 
    //     }

    // }

}

// 44.JavaScript Program to Clone a JS Object
{





}

//45.JavaScript Program to Loop Through an Object

{




}

//46.JavaScript Program to Merge Property of Two Objects

{




}

//47.JavaScript Program to Count the Number of Keys/Properties in an Object

{
    // let object = {
    //         firstName: "raj",
    //         lastName: "shah",
    //         age: 40,
    //     };

    //     sum =0

    //     for (let key in object){

    //     }

}

//48.JavaScript Program to Add Key/Value Pair to an Object

{


}

//49.JavaScript Program to Replace All Occurrences of a String

{

    // let str =`what what what why why why when when when `

    // let regex=/wh/gi

    // console.log(str.replaceAll(regex,"th"));

}

//50.JavaScript Program to Create Multiline Strings

{

    //     let str = `this is cat
    // this is dog
    // this is cow`

    //     console.log(str);

}

//51.JavaScript Program to Format Numbers as Currency Strings

{
    // let num = `2000`

    // let sum=0

    // sum = 85.62 * num

    // console.log(` ${num} inr = ${sum} usd`);

}

//52.JavaScript Program to Generate Random String

{



}

//53.JavaScript Program to Check if a String Starts With Another String

{



}

//54.JavaScript Program to Trim a String

{
    // let str =`    hello    `
    // console.log(str);

    // console.log(str.trim());

}

//55.JavaScript Program to Convert Objects to Strings

{
    
    // let str = new String("    Hello ")

    // console.log(str.toString());
    // console.log(str.valueOf());
    
}

//56.JavaScript Program to Check Whether a String Contains a Substring

{

    // let str =`hello world`

    // console.log(str.substring(6));
    // console.log(str.substring(0,6));
    
}

//57.JavaScript Program to Compare Two Strings

{
    // let str1 =`hello world`
    // let str2 =`hello world`

    // if(str1===str2){
    //     console.log(`both are same`);
    // }else{
    //     console.log(`both not same`);
        
    // }

}

// 58.JavaScript Program to Encode a String to Base64

{

    let str =`Hello world`

    let base64 = btoa(str)

    console.log(base64);

    let decode = atob(base64)

    console.log(decode);

}

//59.JavaScript Program to Replace all Instances of a Character in a String

{




}

//60.JavaScript Program to Replace All Line Breaks with

{




}

//61.JavaScript Program to Display Date and Time

{

    // let date = Date()
    // console.log(date);
    
}

//62