  // f1 = f2
        // f2 = fibbo