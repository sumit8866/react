ng(15));

console.log(str.slice(-15));
console.log(str.substring(-20));

console.log(str.slice(15 , 25));
console.log(str.substring(15 , 25));

console.log(str.slice(-15 , 18));
console.log(str.substring(-15 , 25));

console.log(str.slice(-15 , -18));
console.log(str.substring(-15 , -25));

console.log(str.slice(15 , 0));
console.log(str.substring(15 , 0));