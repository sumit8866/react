// //javascript Number mehtods 
// {

//     // let num = 222

//     // console.log(num);
    
//     // console.log(num.toString());
    
//     // console.log(typeof num);

//     // let str = `30`
//     // console.log(typeof str);

//     // let num2 = Number(str)

//     // console.log(typeof num2);

// }
// {


//     //Number.isFinite()*************************************************

//     //The Number.isFinite() static method determines whether the passed value is a finite number — that is, it checks that a given value is a number, and the number is neither positive Infinity, negative Infinity, nor NaN.

//     // let num = Number.isFinite(0 / 1)
//     // console.log(num);
//     // let num2 = Number.isFinite(1 / 0)
//     // console.log(num2);
//     // let num3 = Number.isFinite(Infinity)
//     // console.log(num3);
//     // let num4 = Number.isFinite(-Infinity)
//     // console.log(num4);
//     // let num5 = Number.isFinite(NaN)
//     // console.log(num5);


//     // Number.isInteger()**************************************************************************

//     // The Number.isInteger() static method determines whether the passed value is an integer


//     //give ans in true and false if number in float than false 
//     // console.log(Number.isInteger(100));
//     // console.log(Number.isInteger(104.6));


//     // Number.isNaN()*************************************************************************************

//     // syntax:
//     // Number.isNaN(value)

//     // console.log(Number.isNaN(NaN));
//     // console.log(Number.isNaN(3));
//     // console.log(Number.isNaN('yy'-5));
//     // console.log(Number.isNaN('yy'/5));


//     // Number.issafeInteger()********************************************************************************

//     // The Number.isSafeInteger() static method determines whether the provided value is a number that is a safe integer.


//     // console.log(Number.isSafeInteger(10));
//     // console.log(Number.isSafeInteger(10000000000000000000000000000));
//     // console.log(Number.isSafeInteger(10.9));
//     // console.log(Number.isSafeInteger(-10));
//     // console.log(Number.isSafeInteger(-10.7));

//     //Number.parseFloat()*************************************************************************************

//     //The Number.parseFloat() static method parses an argument and returns a floating point number. If a number cannot be parsed from the argument, it returns NaN.

//     // console.log(Number.parseFloat(10.34));
//     // console.log(Number.parseFloat(ture));

//     //Number.parseInt()

//     // The Number.parseInt() static method parses a string argument and returns an integer of the specified radix or base.

//     // console.log(Number.parseInt(10))
//     // console.log(Number.parseInt(10.78))


// }

// {

//     //Number.toExponential()******************************************************************************

//     // toExponential()
//     // toExponential(fractionDigits)

//     let num = 69.593039145

//     // console.log(num.toExponential());
//     // console.log(num.toExponential(1));
//     // console.log(num.toExponential(2));
//     // console.log(num.toExponential(3));
//     // console.log(num.toExponential(4));
//     // console.log(num.toExponential(101)); //error

//     //Number.toFixed()******************************************************************************

//     // console.log(num.toFixed());
//     // console.log(num.toFixed(1));
//     // console.log(num.toFixed(2));
//     // console.log(num.toFixed(3));
//     // console.log(num.toFixed(4));
//     // console.log(num.toFixed(5));
//     // console.log(num.toFixed(6));
    
//     //Number.toLocaleString()******************************************************************************
    

//     // console.log(num.toLocaleString('ar-EG'));

//     // let str = NaN
//     // console.log(str.toLocaleString('ar-EG'));
    
//     //Number.toPrecision()******************************************************************************
    
//     // The toPrecision() method of Number values returns a string representing this number to the specified number of significant digits.

//     // console.log(num.toPrecision());
//     // console.log(num.toPrecision(1));
//     // console.log(num.toPrecision(2));
//     // console.log(num.toPrecision(3));
//     // console.log(num.toPrecision(4));
//     // console.log(num.toPrecision(5));
//     // console.log(num.toPrecision(6));
//     // console.log(num.toPrecision(7));
//     // console.log(num.toPrecision(8));
//     // console.log(num.toPrecision(9));
//     // console.log(num.toPrecision(10));
//     // console.log(num.toPrecision(11));
//     // console.log(num.toPrecision(12));
//     // console.log(num.toPrecision(13));
//     // console.log(num.toPrecision(14));
    

    
// }