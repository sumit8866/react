
    // The Number.parseInt() static method parses a string argument and returns an integer of the specified