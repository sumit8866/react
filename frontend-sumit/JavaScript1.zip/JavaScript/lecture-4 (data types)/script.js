// javascript data types

// Primitive Data Types

/*
 string
 number
 boolean
 null
 undefined
 symbol
 Bigint
*/

//non-Primitive Data Type

/*
array
objects
*/

// string

{
    // let str = `20` + 10 // 2010
    // let str = `20` - 10 // 10
    let str = `20` *10 // 200

    console.log(str);
}

// Type Of Operator 

{
    // let x = "this is string"
  
    // console.log(typeof x);
  
    // let num = 1
  
    // console.log(typeof num);
  
    // let value = true
  
    // console.log(typeof value);
  
    // let int = 1n
  
    // console.log(typeof int);
  
    // let symbol = Symbol()
  
    // console.log(typeof symbol);
  
    // let nullValue = null
  
    // console.log(typeof nullValue);
  
    // let unde = undefined
  
    // console.log(typeof unde);
    
    // let array = []
  
    // console.log(typeof array);
  
    // let object = {}
  
    // console.log(typeof object);
    
  }

//   Javascript alert  , Prompt , and conform

{
    // alert(`I am sumit`)
    // let mark = prompt(`Enter mark `,)
    // console.log( parseInt(mark))
    // mark >= 33? console.log(`Pass`)
    //  :console.log(`Fail`);

    // let conform = confirm('Are you sure clear area!!!!')
    // console.log(conform);
}

