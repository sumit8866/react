// function sum(){
//     return 10 + 10
// }

// console.log(sum())

// DOM :- Document Object Model

// document.getElementById('demo').innerHTML = "Hello Javascript !!!!!!!!!!!"

/* Javascript Variables */

/* Javascript Statements */

/* Javascript syntax */

// ES5 / ES6

/* What is Variables */

// var x = 10

// var is variable decalre keyword

// x is variable name

// = is assignement character

// 10 is value

// var y = 20; var z = 50

// console.log(x);
// console.log(y);
// console.log(z);

// {
//     var x = 50
// }

// function sum() {
//     var x = 100
//     return x + x
// }

// console.log(sum());


// console.log(x);

// let variable

// let demo = "toys"

// demo = "truck"

// console.log(demo);

// let demos = "books"

// console.log(demos);

// {
//     let demo = "laptop"
//     console.log(demo);
// }
// const keyword

// const car = "bmw"
// console.log(car);
// car = "maruti"
// console.log(car);

/* javascript is case sensitive language */

// var demo = "200"
var Demo = "500"

// console.log(demo);
console.log(Demo);
