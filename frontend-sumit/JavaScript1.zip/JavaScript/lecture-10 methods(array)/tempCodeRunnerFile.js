 // let array1 = [1, 2, 3, 4, 5, 17, , 908, 21, 678, 0]

    // let array2 = [`yesh`, `raj`, `manav`, `om`, `divy`]


    // console.log(array2.sort());
    // console.log(array1.sort());
    // console.log(array1.sort((a,b)=> a-b));