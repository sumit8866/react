 // for(let i of array){
    //     console.log(i);   
    // }
    // for(let i of num){
    //     console.log(i*69);   
    // }